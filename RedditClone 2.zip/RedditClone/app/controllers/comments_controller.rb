class CommentsController < ApplicationController
  before_action :require_sign_in
  
  helper_method :all_comments 
  
  def create
    @comment = current_user.comments.new(comment_params)
    if @comment.save 
      redirect_to post_url(@comment.post_id)
    else 
      flash.now[:errors] = @comment.errors.full_messages 
      render :new 
    end 
  end

  def new
    @comment = Comment.new(post_id: params[:post_id]) 
  end

  def show
    @comment = Comment.find(params[:id])
  end
  
  def all_comments 
    Comment.all 
  end 
  
  private 
  
  def comment_params 
    params.require(:comment).permit(:content, :post_id, :author_id)
  end 
end

class PostsController < ApplicationController
  before_action :require_sign_in 
  before_action :current_user_is_author?, only: [:edit, :update]
  
  def new
    @post = Post.new
  end

  def create
    @post = Post.new(post_params)
    @post.author_id = current_user.id
    if @post.save
      redirect_to post_url(@post)
    else 
      flash.now[:errors] = @post.errors.full_messages 
      render :new   
    end 
  end

  def edit
    @post = current_post
  end

  def update
    @post = current_post
    if @post.update_attributes(post_params)
      redirect_to post_url(@post)
    else 
      flash.now[:errors] = @post.errors.full_messages 
      render :edit 
    end 
  end

  def show
    @post = Post.find(params[:id])
  end

  def destroy
  end
  
  private 
  
  def current_user_is_author?
    current_user.id == current_post.author_id 
  end 
  
  def current_post 
    @current_post ||= Post.find(params[:id])
  end 
  
  def post_params 
    params.require(:post).permit(:title, :content, :sub_ids, :url)
  end
end

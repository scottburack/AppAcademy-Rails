class SubsController < ApplicationController
  before_action :require_sign_in 
  before_action :current_user_is_moderator?, only: [:update, :edit]  
  helper_method :current_user_is_moderator?
  def create
    @sub = Sub.new(sub_params)
    @sub.moderator_id = current_user.id
    if @sub.save 
      redirect_to sub_url(@sub)
    else 
      flash.now[:errors] = @sub.errors.full_messages 
      render :new 
    end 
  end

  def edit
    @sub = current_sub
  end

  def update
    @sub = current_sub
    if @sub.update_attributes(sub_params)
      redirect_to sub_url(@sub)
    else 
      flash.now[:errors] = @sub.errors.full_messages 
      render :edit 
    end 
  end

  def new
  end

  def index
    @subs = Sub.all
  end

  def show
    @sub = Sub.find(params[:id])
  end
  
  private 
  
  def sub_params
    params.require(:sub).permit(:title, :description)
  end
  
  def current_user_is_moderator?
    current_user.id == current_sub.moderator_id 
  end 
  
  def current_sub 
    @current_sub ||= Sub.find(params[:id])
  end 
end

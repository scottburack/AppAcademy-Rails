Rails.application.routes.draw do

  

  resources :users do 
    resources :subs, only: [:edit, :update] do
      resources :posts, only: [:edit, :update, :destroy]
        resources :comments, only: [:update, :edit, :destroy]
    end 
  end 
  
  resource :session, only: [:create, :new, :destroy]
  resources :subs, except: :destroy do 
    resources :posts, only: [:create, :new]
  end 
  resources :posts, except: :index do 
    resources :comments, only: [:new]
  end 
  
  resources :comments, only: [:create, :show]

  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
